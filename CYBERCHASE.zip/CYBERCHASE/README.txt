welcome to CYBERCHASE!
in a few moments you will partake in a race across the galaxy aimed at stopping an evil organisation intent on destroying the universe!
but first, the boring bit. 
the gameplay of CYBERCHASE may seem odd.
----------------------------------------------------------how 2 play---------------------------------------------------------------------------------
in CYBERCHASE you will be given a short paragraph and a colon mark (:).
you must first read the text and then type in a command.
after typing in the command, you must press enter to execute it
the screen clears every time you reach a new level.
---------------------------------------------------------commands------------------------------------------------------------------------------------
here is a list of commands, what they do and how to use them.

movement (n,s,e and w)
example scenario: you come into a room containing two doors to the east and west.
use e  to go east and w to go west.

open
example scenario: you enter a room containing a box.
use openbox to open it.

hit
example scenario: you enter a room containing a criminal.
use hitcriminal to hit them.

eat
example scenario: you enter a room containing a plate of mince.
use eatmince to eat it.

sleep
example scenario: you enter a room containing a bed.
use sleep to have a lie down.

drink
example scenario: you enter a room containing a glass of water.
use drinkwater to drink it.

answer
example scenario: you find yourself in a room containing a message on the wall that reads: what colour is the sky?
use blue to progress.

move
example scenario: you enter a room containing a footstool.
movestool or movefootstool will move it.
you cannot move tables or chairs.

shred 
example scenario: you enter a room containing a shredder and a sheet of paper.
shredpaper would obliterate it.

---------------------------------------------------------legal agreement----------------------------------------------------------------------------
there is none.
--------------------------------------------------------other---------------------------------------------------------------------------------------
you can not use any spaces in your commands (other then your avatar name).
enjoy!